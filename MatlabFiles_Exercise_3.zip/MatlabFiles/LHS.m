%%%%%%%%%%%%%%%%%%%%%% LHS.m %%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Implement a Latin Hypercube sampling 

clear all;
clc;
close all;

dim = 2;
samp = 100;

N = samp;
% N=10e3;

sigma2 = 1;
mu2 = 20;
% a = normrnd(mu2,sigma2,dim,N);
a = rand(dim,N);

%%
for d =1:dim
	% 1 - Range of known CDF is divided into N (number of samples) disjoint intervals
    b(d,:) = quantile(a(d,:),samp);
% 	b = [0*ones(d,1),baux,1*ones(d,1)];

    % 2 - One value of each interval Skn is chosen randomly
	for i = 1 : length(b)-1
        X(d,i) = random('Uniform',b(d,i),b(d,i+1));
%         X(d,i) = unifrnd(b(d,i),b(d,i+1));
    end
    ind = randperm(samp-1);
    X(d,:) = X(d,ind);
        
end


% % % plot 1D
% figure(1);clf
% hax = axes;
% plot(X,zeros(length(X),1),'o')
% hold on
% for il = 1:length(b)
%     line([b(il) b(il)],[0 1],'Color',[1 0 0])
% end
% 
% % plot 2D
figure(1);clf
plot(X(1,:),X(2,:),'.','MarkerSize',10)
hold on
for d = 1:dim
for il = 1:length(b)
    if d == 1
    line([b(1,il) b(1,il)],[0 1],'Color',[1 0 0])    
    end
    if d == 2
    line([0 1],[b(2,il) b(2,il)],'Color',[1 0 0])    
    end
end
end


%%
dim = 2;
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Matlab built-in functions
mat_X = lhsdesign(samp,dim);
% mat_X = lhsnorm(mu,sigma,samp);
% mat_X = sort(mat_X);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%


figure(2);clf;
% plot(mat_X,'o')
% for i = 1:dim
    plot(mat_X(:,1),mat_X(:,2),'o')
    hold on
%     plot(mat_X(i,:),'.')
% end
xlabel('Random variable','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)

%%
figure(10);clf;
for i = 1:dim
    plot(X(i,:),'o')
    hold on
end
xlabel('Sample number','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)


%%
figure(3);clf;
plot(X(1,:),X(2,:),'o')
hold on
% set(gca,'ytick',sort(b(1,:)),'xtick',sort(b(1,:)))
grid on
% plot(mat_X(:,1),mat_X(:,2),'o')
xlabel('Sample number','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)
hold on
for d = 1:dim
for il = 1:length(b)
    if d == 1
    line([b(1,il) b(1,il)],[0 1],'Color',[1 0 0])    
    end
    if d == 2
    line([0 1],[b(2,il) b(2,il)],'Color',[1 0 0])    
    end
end
end

%% Alternative


% data = a;
% nsample  = 10;
% [m,nvar]=size(data);
% ran=rand(nsample,nvar);
% s=zeros(nsample,nvar);
% for j=1: nvar
%    idx=randperm(nsample);
%    P=((idx'-ran(:,j))/nsample).*100;
%    s(:,j)=prctile(data(:,j),P);
% end
% 
% 
% figure(3);clf
% plot(s,'o')
