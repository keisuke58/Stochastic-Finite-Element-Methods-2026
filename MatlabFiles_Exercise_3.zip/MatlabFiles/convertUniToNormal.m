function [n] = convertUniToNormal(x,mu,sigma)


space = linspace(mu-4*sigma,mu+4*sigma,100);

pd = makedist('Normal','mu',mu,'sigma',sigma);

pd.cdf(space);

n = icdf(pd,x);

end