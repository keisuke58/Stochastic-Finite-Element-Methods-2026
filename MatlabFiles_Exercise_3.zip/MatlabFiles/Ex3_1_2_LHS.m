%%%%%%%%%%%%%%%%%%%%%% LHS.m %%%%%%%%%%%%%%%%%%%%%%%%
%%%%% Implement a Latin Hypercube sampling 

clear all;
clc;
close all;

dim = 2;
samp = 100;

N = samp;
% N=10e3;


rng('default')
sigma2 = 1;
mu2 = 20;
% a = normrnd(mu2,sigma2,dim,N); % for normal distribution
a = rand(dim,N); % for uniform distribution
for d =1:dim
% 	% 1 - Range of known CDF is divided into N (number of samples) disjoint intervals
% % 	b = quantile(a,(1/samp:1/samp:1));
    b = quantile(a,samp);
	
	% 2 - One value of each interval Skn is chosen randomly
	for i = 1 : length(b)-1
%         X(d,i) = random('Uniform',b(1,i),b(1,i+1));
        X(d,i) = unifrnd(b(i),b(i+1));
    end
    ind = randperm(samp-1);
    X(d,:) = X(d,ind);
        
end
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
% % Matlab built-in functions
mat_X = lhsdesign(samp,dim);
% mat_X = lhsnorm(mu2,sigma2,samp, dim);
% mat_X = sort(mat_X);
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
figure(1);clf;
for i = 1:dim
    plot(X(i,:),'o')
    hold on
end
xlabel('Sample number','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)

figure(2);clf;
% plot(mat_X,'o')
for i = 1:dim
    plot(mat_X(:,i),'o')
    hold on
%     plot(mat_X(i,:),'.')
end
xlabel('Sample number','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)

figure(3);clf;
plot(X(1,:),X(2,:),'o')
hold on
% set(gca,'ytick',sort(b(1,:)),'xtick',sort(b(1,:)))
grid on
% plot(mat_X(:,1),mat_X(:,2),'o')
xlabel('Sample number','FontSize',16)
ylabel('Random variable','FontSize',16)
set(gca,'FontSize',12)

