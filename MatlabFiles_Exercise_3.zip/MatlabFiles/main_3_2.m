clear; clc; close all;
nb_data = 1e3;
%function[]=compare(nb_data)
random_data_MC = random('Uniform',0,1,nb_data,2);
random_data_lhs = lhsdesign(nb_data,2);
random_data_sobol = net(sobolset(2),nb_data);
figure
scatter(random_data_MC(:,1),random_data_MC(:,2));
title(['Monte Carlo - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
%%
figure
scatter(random_data_lhs(:,1),random_data_lhs(:,2));
title(['LHS - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
%%
nb_data = 1e3; close all; clc; random_data_sobol = net(sobolset(2),nb_data);
figure
scatter(random_data_sobol(:,1),random_data_sobol(:,2));
title(['Sobol sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
%%