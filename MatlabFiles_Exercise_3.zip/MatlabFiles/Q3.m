%%%%%%%%%%%%%%%% Q3.m


%% Histogram
% % % gauss generator
z = rand_gauss(10,2,200);

figure(1);clf
hist(z);

figure(2);clf
Y = normrnd(10, 2, 1, 200); 
hist(Y);
% % % % Log-normal
% Z = random('logn',100,0.5,1000,1);		
% hist(Z,520)
% % % % Weibull
% Z = random('Weibull',1.3,0.5,1000,1);	
% hist(Z,800)

%% PDF


% % Plot gaussian LHS sampling
% [nelem,center]=hist(random_data2,30);
% 
% % PLot gaussian Monte-Carlo sampling
% X = normrnd(mu2,sigma2,1,N);
% [nelem2,center2]=hist(X,30);
% hold off

sigma2 = 10;
mu2 = 2;
nelem2 = 10;
m = 2;

% Plot Gaussian Law
% aa=16000:500:26000;
aa = -50:1:50;
bb = 1000*1/sqrt(2*pi*power(sigma2,2)) * exp(-power((aa-mu2),2)/(2*power(sigma2,2)));

hold on
plot(aa,bb,'r','linewidth',2);
% hold on
% plot(center2,nelem2/(sum(nelem2)*(center2(2)-center2(1))),'g','linewidth',2)
% plot(center,nelem/(sum(nelem)*(center(2)-center(1))),'b','linewidth',2)

% legend('Gaussian Law','Monte Carlo sampling','LHS sampling')
% legend('boxoff')
% axis([16000 26000 0 5e-4])
% set(gca,'FontSize',30,'fontName','Times');
% xlabel('Young modulus [MPa]')
% ylabel('f_{X}(x)')