%%%%%%%%%%%%%%%%%% MCS.m %%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;

seed = 46*1e5; % seed u_0

a = 10e3 ;       % multiplier
c = 0 ;          % increment
m = 2^31 - 1 ;   % modulus

dim = 2;             % dimension of the sampling (e.g. 1 for 1D sampling)
nsamp = 100;         % Number of samples

z = ones(dim,nsamp); % initialization of the random variable 

z(1,1) = seed;   % assigning the initial value z0, or seed.

% % % loop over the number of dimensions to create different seeds in each dimension
if size(z,1) > 1
    for j = 2:size(z,1)
        z(j,1) = seed + j*(j+1)*seed; 
    end
end

% % % generate the random numbers in
for i=2:size(z,2)
    z(:,i) = ... ; % Complete the line with appropriate expression
end
x = z/m;

figure(1);clf;
for i = 1:dim
    plot(x(i,:),'.')
    hold on
end
xlabel('Sample number')
ylabel('Random variable')
set(gca,'FontSize',16)

%% Ex 1.3 Matrix Congruential generator

% % Create a matrix of multipliers a_ij
a11 = 17;
a22 = 85;
a12 = 3;
a21 = 3;
A = [a11 a12; a21 a22]; 

%%% complete the code for a Matrix congruential generator
% % % ...