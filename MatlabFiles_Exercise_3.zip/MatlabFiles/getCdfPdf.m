%%%%%%%%%%%%%%%%%%%%%%% getCdfPdf.m %%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%% This function estimates the cumulative distribution function (CDF)
%%%%%% and the probability density function (PDF)  from an experimental set
%%%%%% of discrete data and compares with Matlab built-in functions.

% clear all;
% clc;

% n = 500;
% 
% %% Uniform discrete data 
% % A = 15 + 10*rand(1,n);
% 
% %% Gaussian distribution
% sigma=1;
% mu = 18.5;
% 
% A = normrnd(mu,sigma,[1 n]);
% 
% % % A = sort(r); % sort vector elements 
% Er = mu;
% PE_mu = 1/(sqrt(2*pi*sigma^2))*exp(-(Er-mu)^2/(2*sigma^2))
% 
% %% Weibuul distribution
% % r=20+10*wblrnd(0.2,1,[1,n]);
% % r = sort(r); % sort vector elements 
% 
% %% discretization
% x_min = 15;
% x_max = 25;
% 
% nb_interval = 100;
% dx = (x_max-x_min)/nb_interval;
% x = [x_min:dx:x_max];
% B = sort(A);
% % B=A;

function [cdf,pdf,cdf2]=getCdfPdf(x,B)

n = length(B);

%% Estimate the cumulative distribution function (CDF)
% cdf = zeros(size(x));
% cdfaux=0;
% j=1;
% for i = 1:length(x)
%     j = 1;
%     if (x(i)-B(j)) > 0        
%         cdf(i) = j/length(B);
%         cdfaux = cdf(i);
%         for k= (j+1):length(B)
%             if (x(i)-B(k))>0
%                 cdf(i) = k/length(B);
%             end            
%         end        
%     else
%         cdf(i) = 0;
%     end
% end
for i = 1:length(x)
    cdf(i) = numel(B(B<x(i)))/n;
end

[Fx,x1] = ecdf(B);



%% Estimate the probability density function
pdf = zeros(size(x));
% for i= 1:length(x)
%     if i==length(x)
%         pdf(i) = (cdf(i)-cdf(i-1))/(x(i)-x(i-1));
%     else
%         pdf(i) = (cdf(i+1)-cdf(i))/(x(i+1)-x(i));
%     end
% end
for i= 1:length(x)
    if i==1
        pdf(i) = (cdf(i+1)-cdf(i))/(x(i+1)-x(i));
    elseif i== length(x)
        pdf(i) = (cdf(i)-cdf(i-1))/(x(i)-x(i-1));
    else
        pdf(i) = (cdf(i+1)-cdf(i-1))/(x(i+1)-x(i-1));
    end
end

%% Estimate CDF from estimated PDF
cdf2 = zeros(size(x));
cdf2(1) = 0;
cdf2(length(x)) = 1;
for i = 2:length(x)-1
    cdf2(i) = cdf(i-1)+ (x(i)-x(i-1))*(pdf(i-1)+pdf(i+1))/2;
end

%% plots
figure(1);clf;
plot(x1,Fx,'.',x,cdf,x,cdf2,'.')
set(gca,'xlim',[15 25],'ylim',[0 1])
ylabel('Cumulative Distribution Function')

figure(2);clf;
plot(x,pdf)
set(gca,'xlim',[15 25],'ylim',[0 1])
ylabel('Probability Density Function')
grid on
