%%%%%%%%%%%%%%%% Q3.m

function [X] = rand_gauss(myMean,var,N)

X = normrnd(myMean,sqrt(var),1,N);
[nelem,center]=hist(X,30);
hold off
% aa=-1.0:0.01:2.00;
aa = linspace(myMean-4*var,myMean+4*var,100);
bb = 1/sqrt(2*pi*power(sqrt(var),2)) * exp(-power((aa-myMean),2)/(2*power(sqrt(var),2)));
plot(aa,bb,'r');
hold on
plot(center,nelem/(sum(nelem)*(center(2)-center(1))),'b');