function [error_mean]= error_gauss_gen(nb_samp)

% Gaussian random data generator
des_mean = 100 ;              % desired mean
des_dev = 0.5 ;              % desired standard deviation = Variance**0.5

Y = normrnd(des_mean, des_dev, 1, nb_samp);

true_mean = mean(Y);
true_dev = sqrt(var(Y));

% disp('des_mean='); disp(des_mean);
% disp('true_mean='); disp(true_mean);
% disp('des_dev='); disp(des_dev);
% disp('true_dev='); disp(true_dev);

error_mean = abs(des_mean - true_mean) ;
error_dev = abs(des_dev - true_dev) ;

% error_mean = sqrt(des_mean^2 - true_mean^2) ;
% error_dev = sqrt(des_dev^2 - true_dev^2) ;