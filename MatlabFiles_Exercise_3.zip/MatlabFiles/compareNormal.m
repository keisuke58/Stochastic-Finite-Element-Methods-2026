clear all;
clc;

nb_data = 1000;

mu = 0.5;
sigma = 0.1;

% % % MC
random_data_MC = random('Normal',mu,sigma,nb_data,2);

% % % LHS
% random_data_lhs = lhsdesign(nb_data,2);
random_data_lhs = lhsnorm([mu,mu] ,[sigma^2,0;0,sigma^2],nb_data); % vecotr with mean,[mu mu], and convariance matrix 

% % % Sobol
ps = sobolset(2);
ps = scramble(ps,'MatousekAffineOwen');
random_data_sobol = net(ps,nb_data);
random_data_sobol = norminv(random_data_sobol,mu,sigma);
% random_data_sobol = mu + sqrt(2)*sigma*erfinv(2*random_data_sobol-1);

% % % Halton
ph = haltonset(2);
ph = scramble(ph,'RR2');
random_data_halton = net(ph,nb_data);
random_data_halton = norminv(random_data_halton,mu,sigma);
% random_data_halton = mu + sqrt(2)*sigma*erfinv(2*random_data_halton-1);

%% convergence
mean_MC = mean(random_data_MC)
mean_lhs = mean(random_data_lhs)
mean_sobol = mean(random_data_sobol)
mean_halton = mean(random_data_halton(2:end,:))

%%
figure(1);clf;
scatter(random_data_MC(:,1),random_data_MC(:,2));
title(['Monte Carlo - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])

figure(2);clf
scatter(random_data_lhs(:,1),random_data_lhs(:,2));
title(['LHS - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])


figure(3);clf
scatter(random_data_sobol(:,1),random_data_sobol(:,2));
title(['Sobol sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])

figure(4);clf
scatter(random_data_halton(:,1),random_data_halton(:,2));
title(['Halton sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])




