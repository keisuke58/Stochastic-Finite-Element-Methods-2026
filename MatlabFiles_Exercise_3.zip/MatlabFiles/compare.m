clear all;
clc;
close all;


nb_data = 2e3;

%MC
random_data_MC = random('Uniform',0,1,nb_data,2);
% LHS
random_data_lhs = lhsdesign(nb_data,2);
% Sobol
ps = sobolset(2);
ps = scramble(ps,'MatousekAffineOwen');
random_data_sobol = net(ps,nb_data);
% Halton
ph = haltonset(2);
ph = scramble(ph,'RR2');
random_data_halton = net(ph,nb_data);


%%
figure(1);clf;
scatter(random_data_MC(:,1),random_data_MC(:,2));
title(['Monte Carlo - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on

figure(2);clf
scatter(random_data_lhs(:,1),random_data_lhs(:,2));
title(['LHS - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on

figure(3);clf
scatter(random_data_sobol(:,1),random_data_sobol(:,2));
title(['Sobol sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on


figure(4);clf
scatter(random_data_halton(:,1),random_data_halton(:,2));
title(['Halton sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on