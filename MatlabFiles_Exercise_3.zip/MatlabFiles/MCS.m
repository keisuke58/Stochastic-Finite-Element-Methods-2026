%%%%%%%%%%%%%%%%%% MCS.m %%%%%%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;
close all;

seed = 1; % seed u_0
% seed = 40*1e3*cputime

a = 7 ;       % multiplier
c = 1 ;          % increment  (if zero the generator is called "multiplicative conguential generator"
m = 2^22 - 1 ;   % modulus

dim = 1;             % dimension of the sampling (e.g. 1 for 1D sampling)
nsamp = 1e3;         % Number of samples

z = ones(dim,nsamp); % initialization of the random variable 

z(1,1) = seed;   % assigning the initial value z0, or seed.

% % % loop over the number of dimensions to create different seeds in each dimension
% if size(z,1) > 1
%     for j = 2:size(z,1)
%         z(j,1) = seed + j*(j+1)*seed; 
%     end
% end

% % % generate the random numbers in
for i=2:size(z,2)
    z(:,i) = mod(a*z(:,i-1)+c,m) ;
end

x = z/m;

figure(1);clf;
%{
for i = 1:dim
    plot(x(i,:),'.')
    hold on
end
%}
 plot(x,'.')
xlabel('Sample number')
ylabel('Random variable')
set(gca,'FontSize',16)
%%
u=x;
close all; clc;
figure;
plot(u(1:length(u)-1), u(2:length(u)),'LineStyle','none','Marker','o')
xlabel('$x_{ i + 1}$');
ylabel('$x_{ i }$');

%% matlab function seed control
% rng(seed)      % specify seed
rng('shuffle') % seed based on current time
% rng('default')   % seed produced at the start of matlab
rand(10,1)

%% Ex 1.3 Matrix Congruential generator

% % Create a matrix of multipliers a_ij
a11 = 17;
a22 = 85;
a12 = 3;
a21 = 3;
A = [a11 a12; a21 a22]; 

c = 0 ;          % increment
m = 2^13 - 1 ;   % modulus

seed = 46*1e2;  % assigning the initial value z0, or seed.

dim = 1;

z = ones(2,nsamp); % initialization of the random variable 
z(1,1) = seed;
z(2,1) = seed;

for i=2:size(z,2)
    z(:,i) = mod(A*z(:,i-1),m) ;
end

u = z/m;

figure(2);clf
plot(u(1,:),'.')
hold on
plot(u(2,:),'.')
xlabel('Sample number')
ylabel('Random variable')
set(gca,'FontSize',16)

%% get normal distribution

x = rand(1000,1);
n = convertUniToNormal(x,mu,sigma);
figure(10);clf
histogram(n,10,'Normalization','probability')

