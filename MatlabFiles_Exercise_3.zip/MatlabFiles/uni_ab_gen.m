%%%% uni_ab_gen.m

clear all;
clc;
close all


N = 100;

a = 10;
b = 20;
space = linspace(a,b,N);

U = rand(N,1);

X = a+U*(b-a);


plot(X,'.')

%% exp_gen.m

lambda = 0.5;

X = -log(1-U)/lambda;

plot(X,'.')