function []= eval_gen()
nb_test=1500;
for i=1:nb_test
% z = rand_gen(1,i);
z = rand(1,i);
% z2 = exp_gen(z,15);
z2= random('exp',1/15,1,nb_test);
N(i)=i;
the_mean(i) = mean(z);
the_var(i) = var(z);
the_skew(i) = skewness(z);
the_kurt(i) = kurtosis(z);
%
the_mean2(i) = mean(z2);
the_var2(i) = var(z2);
the_skew2(i) = skewness(z2);
the_kurt2(i) = kurtosis(z2);
end