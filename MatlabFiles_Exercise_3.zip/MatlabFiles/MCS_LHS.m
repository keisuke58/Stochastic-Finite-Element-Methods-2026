%%%% Comparison between Monte-Carlo and Latin Hypercube Sampling

clear all;
close all
clc;

%% LHS
N= 1e4;
rng('default')
sigma2 = 500;
mu2 = 20000 ;
dim = 2;
samp = N;
a = normrnd(mu2,sigma2,1,N);
% a = rand(N);
for d =1:dim
    % 1 - Range of known CDF is divided into N (number of samples) disjoint intervals
%     b = quantile(a,(1/samp:1/samp:(1-1/samp)));
    b = quantile(a,samp);
    
    % 2 - One value of each interval Skn is chosen randomly
    for i = 1 : length(b)-1
        random_data_lhs1(d,i) = random ('Uniform',b(i),b(i+1));        
    end
    ind = randperm(samp-1);
    random_data_lhs1(d,:) = random_data_lhs1(d,ind);
end

%%
% random_data_lhs = lhsdesign(N,dim);
muvec = mu2*ones(1,dim)';
sigmavec = sigma2*eye(dim)
random_data_lhs = lhsnorm(muvec,sigmavec,N);

figure(1);clf
plot(random_data_lhs(:,1),random_data_lhs(:,2),'o');

figure(2);clf
plot(random_data_lhs1(1,:),random_data_lhs1(2,:),'o');


%%
nInt = 50;
% Plot gaussian LHS sampling
[nelem,center]=hist(random_data_lhs1,nInt);
figure(1);clf
histogram(random_data_lhs1,nInt);

% PLot gaussian Monte-Carlo sampling
X = normrnd(mu2,sigma2,1,N);
[nelem2,center2]=hist(X,nInt);
hold off

% Plot Gaussian Law
aa=16000:50:26000;
bb = 1/sqrt(2*pi*power(sigma2,2)) * exp(-power((aa-mu2),2)/(2*power(sigma2,2)));

figure(3);clf
plot(aa,bb,'r','linewidth',2);
hold on

plot(center2,nelem2/(sum(nelem2)*(center2(2)-center2(1))),'g','linewidth',2)
plot(center,nelem/(sum(nelem)*(center(2)-center(1))),'b','linewidth',2)

legend('Gaussian Law','Monte Carlo sampling','LHS sampling')
legend('boxoff')
axis([16000 26000 0 1e-3])
set(gca,'FontSize',18,'fontName','Times');
xlabel('Young modulus [MPa]')
ylabel('f_{X}(x)')

% cdfplot(z);
% cdfplot(z2);
% [F,x] = ecdf(z2)