
clear all;
clc;
close all;

nbvec = [100 1000 10000 100000];

for i = 1:length(nbvec)
    

nb_data = nbvec(i);

mu = 0.5;
sigma = 0.1;
dim = 10;

% % % MC
random_data_MC = random('Normal',mu,sigma,nb_data,dim);

% % % LHS
% random_data_lhs = lhsdesign(nb_data,2);
random_data_lhs = lhsnorm(mu*ones(1,dim) ,sigma^2*eye(dim),nb_data); % vecotr with mean,[mu mu], and convariance matrix 
% % % Sobol
ps = sobolset(dim);
ps = scramble(ps,'MatousekAffineOwen');
random_data_sobol = net(ps,nb_data);
random_data_sobol = norminv(random_data_sobol,mu,sigma);
% random_data_sobol = mu + sqrt(2)*sigma*erfinv(2*random_data_sobol-1);

% % % Halton
ph = haltonset(dim);
ph = scramble(ph,'RR2');
random_data_halton = net(ph,nb_data);
random_data_halton = norminv(random_data_halton,mu,sigma);
% random_data_halton = mu + sqrt(2)*sigma*erfinv(2*random_data_halton-1);

%% convergence
mean_MC(i,:) = mean(random_data_MC);
mean_lhs(i,:) = mean(random_data_lhs);
mean_sobol(i,:) = mean(random_data_sobol);
mean_halton(i,:) = mean(random_data_halton(2:end,:));

err_MC(i,:) = abs(mean_MC(i,:)-mu)/mu*100;
err_lhs(i,:) = abs(mean_lhs(i,:)-mu)/mu*100;
err_sobol(i,:) = abs(mean_sobol(i,:)-mu)/mu*100;
err_halton(i,:) = abs(mean_halton(i,:)-mu)/mu*100;

end
%% plot
figure(1);clf;
p1=semilogx(nbvec,err_MC,'b');
hold on
p2=semilogx(nbvec,err_lhs,'r');
p3=semilogx(nbvec,err_sobol,'g');
p4=semilogx(nbvec,err_halton,'m');
legend([p1(1),p2(1),p3(1),p4(1)],'Monte-Carlo','LHS','Sobol','Halton')
set(gca,'FontSize',14,'ylim',[0 1])
xlabel('Number of samples','FontSize',16)
ylabel('Relative error (%)','FontSize',16)


%%
figure(10);clf;
scatter(random_data_MC(:,1),random_data_MC(:,2));
title(['Monte Carlo - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])

figure(20);clf
scatter(random_data_lhs(:,1),random_data_lhs(:,2));
title(['LHS - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])


figure(30);clf
scatter(random_data_sobol(:,1),random_data_sobol(:,2));
title(['Sobol sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])

figure(40);clf
scatter(random_data_halton(:,1),random_data_halton(:,2));
title(['Halton sequences - N = ', num2str(nb_data)],'Fontsize',16,'Fontweight','Bold')
set(gca,'Fontsize',16,'fontweight','Bold')
box on
grid on
axis([0 1 0 1])




