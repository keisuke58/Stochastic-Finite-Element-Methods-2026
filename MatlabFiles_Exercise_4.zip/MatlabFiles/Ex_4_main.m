%clear; clc; close all;
%%
L = 2;
nx = 1e2;
xnod = linspace(0,L, nx)';
lx = 1;
KL_terms = 6;
%%
[X1,X2] = meshgrid(xnod);
Cov = exp(-abs(X1-X2)/lx);
[evec_dis,eval] = eigs(Cov,KL_terms);
%%
KL_analytical = kl_exponential(xnod, KL_terms, lx);
%%
cov_kernel = @(x1,x2) exp(-abs(x1-x2)/lx);
[eigvec, eigval] = KL_Galerkin(KL_terms, cov_kernel, xnod);
%%
%close all; clc;
figure
plot(xnod,KL_analytical.*sign(KL_analytical(1,:)),'r-');
hold on;
plot(xnod,evec_dis.*sign(evec_dis(1,:)),'b--');

plot(xnod,eigvec.*sign(eigvec(1,:)),'g.');
%%