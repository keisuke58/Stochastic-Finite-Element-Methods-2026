function [eigvec, eigval] = KL_Galerkin(KL_terms, cov_kernel, xnod)
% Solution of the Fredholm integral using Galerkin FEM procedure
%% FEM parameters
ned  = 1;                         % number of dof per node
nen  = 2;                         % number of nodes per element
nnp  = length(xnod);              % number of nodal points
nfe  = nnp - 1;                   % number of finite elements
neq  = ned*nen;                   % number of element equations
ndof = ned*nnp;                   % number of degrees of freedom
IEN  = [(1:(nnp-1))' (2:nnp)']';  % loc-glo
ID   = 1:ndof;

% localization matrix
LM = cell(nfe,1);
for e = 1:nfe
    LM{e} = [ID(IEN(1,e)); ID(IEN(2,e))];
end

%% two-node 1D elements: lagrangian shape functions
Nshape = @(xi) [ -(xi-1)/2, (xi+1)/2 ]';    % [N1, N2]

%% Gauss-Legendre parameters
nGL = 3;                 % Gauss-Legendre quadrature order
[x_gl, w_gl] = gauss_quad(nGL);

%% Computing matrix B
B = sparse(ndof, ndof);
%tic;
for e = 1:nfe
    Be = zeros(neq);
    det_Je = (xnod(IEN(2,e))-xnod(IEN(1,e)))/2;
    
    % gauss-legendre quadrature integration
    for p = 1:nGL
        xi_gl = x_gl(p);
        NN = Nshape(xi_gl);    % shape functions on GL points
        
        % B matrix
        Be = Be + NN'.*NN*det_Je*w_gl(p);
    end
    B(LM{e}, LM{e}) = B(LM{e}, LM{e}) + Be;
end
%toc;

%% computing matrix C
C = sparse(ndof,ndof);
%tic;
for e = 1:nfe
    xe = xnod(IEN(:,e));
    det_Je = (xnod(IEN(2,e))-xnod(IEN(1,e)))/2;
    for f = 1:nfe
        Cef = zeros(nen);
        xf = xnod(IEN(:,f));
        det_Jf = (xnod(IEN(2,f))-xnod(IEN(1,f)))/2;
        for p1 = 1:nGL
            xi_gl_e = x_gl(p1);
            NNe = Nshape(xi_gl_e);   % shape function of element e
            xp1 = sum(NNe.*xe);      % in global coordinates
            for p2 = 1:nGL
                xi_gl_f = x_gl(p2);
                NNf = Nshape(xi_gl_f);   % shape function of element f
                xp2 = sum(NNf.*xf);      % in global coordinates
                
                % element C matrix
                Cef = Cef + cov_kernel(xp1, xp2)'.*NNe'.*NNf*det_Je*det_Jf*w_gl(p1)*w_gl(p2);
            end
        end
        C(LM{e},LM{f}) = C(LM{e},LM{f}) + Cef;
    end
end
%toc;
%% solve generalized eigenvalue problem: CA = BAD
[eigvec,eigval] = eigs(C, B, KL_terms);
%
for ik = 1:KL_terms
    eigvec(:,ik) = eigvec(:,ik)/norm(eigvec(:,ik));
end
%% END