clear; clc; close all;
load('Geo_mesh_Rocket.mat');
%%
figure
pdeplot3D(nodes,elements,'facecolor','w');
Axis_xyz_close(15);
%%
Lx = max(nodes(1,:))-min(nodes(1,:)); 
Ly = max(nodes(2,:))-min(nodes(2,:));
Lz = max(nodes(3,:))-min(nodes(3,:));

X = nodes(1,:); Y =nodes(2,:); Z = nodes(3,:);
[X1,X2] = meshgrid(X,X);
[Y1,Y2] = meshgrid(Y,Y);
[Z1,Z2] = meshgrid(Z,Z);
C = exp(-abs(X1-X2)/Lx - abs(Y1-Y2)/Ly - abs(Z1-Z2)/Lz);
%%
tic
KL_terms = 6;
[V,Dc] = eigs(C,KL_terms);
t_KL = toc;
%%
close all; clc;
figure
for id = 1:KL_terms
    subplot(2,3,id)
    pdeplot3D(nodes,elements,'colormap',V(:,id));
    Axis_xyz_close(15);
end
%% Sample
close all; clc;
figure
    pdeplot3D(nodes,elements,'colormap',0.1+V*randn(KL_terms,1));
    Axis_xyz_close(15);
%%
close all; clc;
figure
    pdeplot3D(nodes,elements,'colormap',V(:,6));
    Axis_xyz_close(15);
%%