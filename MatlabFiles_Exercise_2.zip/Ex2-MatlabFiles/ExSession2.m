% % % % Session 2 % % % % % 

clear all;
clc;

samp = 1000; % number of samples
dim = 1; % dimension

%% Get Random Variables (r- discrete random variable; u-uniform contiuous; n- normal continuous)
[r,u,n,w]=getRandom(samp,dim); 

%% get pdf and cdf
% % define sample space
x_max = 20;
x_min = 30;
nb_interval = 100;
dx = (x_max-x_min)/nb_interval;
x = [x_min:dx:x_max];

getCdfPdf(x,n);

%% getMoments 
% % Choose momentes for r, u, n or w:
% [EmpMean,EmpVar,EmpSkew,EmpKurt] = get_moments(n)

%% get Covariance and Correlation
% [my_covar,my_corre] = getCovarianceCorrelation(n,u)
% 
x = [-10 -9 -8 -7 -6 -5 -4 -3 -2 -1 0 1 2 3 4 5 6 7 8 9 10];
% y = x.^2;
y = randi([-10 10],1,21);

[my_covar,my_corre]= getCovarianceCorrelation(x,y)
[my_covar,my_corre]= getCovarianceCorrelation(x,x);
[my_covar,my_corre]= getCovarianceCorrelation(x,-2*x);


