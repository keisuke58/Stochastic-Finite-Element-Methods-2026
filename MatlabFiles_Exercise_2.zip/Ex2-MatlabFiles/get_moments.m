function  [EmpMean,EmpVar2,EmpSkew,EmpKurt]=get_moments(x)

%% Empirical Mean
EmpMean = sum(x)/numel(x);

%% Empirical Variance
EmpVar = (1/numel(x)*sum(x.^2)-EmpMean.^2);
% EmpVar normalizes Z by N-1 if N>1, where N is the sample size

%%% Unbiased estimator
N = numel(x);
if N>1
    EmpVar2 = EmpVar*N/(N-1);
end

%% Empirical Skewness
EmpSkew = 0.0;
for i = 1:length(x)
    EmpSkew = EmpSkew + power(x(i)-mean(x),3)/(power(EmpVar,1.5)*numel(x));
end

%% Empirical Kurtosis
EmpKurt=0;
for i=1:length(x)
    EmpKurt = EmpKurt + power(x(i)-mean(x),4)/(power(EmpVar,2)*numel(x));
end
% EmpKurt = EmpKurt-3; %excess kurtosis
%% display results
EmpMean;
EmpVar;
EmpSkew;
EmpKurt;
EmpVar2;
return


