%%%%%%%%%%%%%%%% Rand_field.m %%%%%%%%%%%%%%%%%%%%%

clear all;
clc;

%% Q4 - 10
% % % 1-dimensional random field
n = 100;
beam_length = 5; % in meters
beam_pos = linspace(0,beam_length,n);


%%  Distributions 

% % %% Gaussian distribution
sigma=1;
mu = 1;
m = 2; %dimension
% 
r = normrnd(mu,sigma,[m n]);

r(1,:) = 200 + 10*r(1,:);
r(2,:) = 2.453 + 0.5* r(2,:);

figure(1);clf
plot(beam_pos,r(1,:))
xlabel('Beam length (m)')
ylabel('Young`s modulus (GPa)')
set(gca,'FontSize',16)


%% 2-dimensional one-variate random field

 figure(3);clf;
 xspace = linspace(0,5,n);
 yspace = linspace(0,5,n);
 
 [X,Y] = meshgrid(xspace,yspace);
 R = 2.33+0.05*rand(length(xspace));
 
  surf(X,Y,R)
% surf(F)
 view(2)
 c = colorbar;
 xlabel('Concrete smaple length (m)')
 ylabel('Concrete smaple height (m)')
 xlabel(c,'Mass density (Kg.m^{-3})')
  
%% Auto-correlation
nreal = 1000; % number of realizations
 % define the reference point
x0 = 2 ;
x = xspace;

for i = 1:nreal
    field(:,i) = normrnd(mu,sigma,[length(xspace) 1]);
end

% estimate the index relative to the reference point
ind_x0 = floor((x0-x(1))/(x(2)-x(1))) +1;

autocor = zeros(1,length(x));
for kk = 1 : length(x)
    Acor = corrcoef(field(kk,:), field(ind_x0,:));
    autocor(1,kk) = abs(Acor(1,2));
end

h2 = figure(4);clf;
bar(x,autocor,'Linewidth',1.20)

xlabel({'Concrete sample','length (m)'},'Interpreter','Latex','FontSize',16)
ylabel('Correlation between x and x$_{0}$ = 2.5 m','Interpreter','Latex','FontSize',16)

%% question3 -12

x = linspace(0,5,1000);


b = [0.1,1,10,100];
for k = 1:length(b)
    for i = 1:length(x)
        CHH(i,k) = exp(-abs(x(i)-x0)/b(k));
    end
end

figure(5);clf
plot(x,CHH)
xlabel({'Concrete sample','length (m)'},'Interpreter','Latex','FontSize',16)
ylabel('Correlation between x and x$_{0}$ = 2.5 m','Interpreter','Latex','FontSize',16)






