%%%%%%%%%%%%%%%%%% twoRandomVariables.m %%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;

%% Question 4 - Two Variables

sigmaE = 1050 ;
sigmaNu = 0.03 ;

muE = 21000 ;
muV = 0.3 ;

rho = 0.1 ;

E1 = 16000 ;
E2 = 26000 ;

nu1 = 0 ;
nu2 = 0.50 ;

nb_E = 50.0 ;
nb_nu = 50.0 ;

y0 = zeros(nb_E,nb_nu);

for i = 1:(nb_E+1)
    for j = 1:(nb_nu+1)
        E = E1 + (i-1)*(E2-E1)/nb_E ;
        nu = nu1 + (j-1)*(nu2-nu1)/nb_nu ;
        y0(i,j) = 1/(2*pi*sigmaE*sigmaNu*sqrt(1-rho^2))*exp(-1/(2*(1-rho^2))*( (E-muE)^2/sigmaE^2 ...
            + (nu-muV)^2/sigmaNu^2 -2*rho*(E-muE)*(nu-muV)/(sigmaE*sigmaNu)));
    end
end

E = (E1:(E2-E1)/nb_E:E2);
nu = (nu1:(nu2-nu1)/nb_nu:nu2);

figure(1);clf
surf(E,nu,y0)

set(gca,'XTick',[16000 18000 20000 22000 24000 26000],'YTick',[0 0.2 0.4],'ZTick',[0 0.002 0.004 0.006])
axis([16000 26000 0 0.5 0 0.006])

xlabel('E [MPa]','FontSize',25)
ylabel('\nu','FontSize',25)
zlabel('f_{E\nu}(E,\nu)','FontSize',25)

set(gca,'FontSize',20,'fontName','Times');
print(gcf,'-depsc2','TwoVariableGauss.eps');

%% 13

fun = @(E,nu) 1 ./ (2 *pi*sigmaE.* sigmaNu*sqrt(1-rho^2)) .* ...
    exp(-1/(2*(1-rho^2)) .* ( (E - muE).^2 ./ sigmaE.^2 + (nu - muV).^2 ./ sigmaNu.^2 -2*rho*(E-muE).*(nu-muV)/(sigmaE*sigmaNu))) ;

%p_Grenzen = quad2d(fun, 0, v_Grenze, 0, E_Grenze)

Emin = 0 ;
Emax = 500000 ;

numin = 0 ;
numax = 1 ;
 
% q2 = integral2(fun,Emin,Emax,numin,numax)

q2 = quad2d(fun,Emin,Emax,numin,numax)

%% 14
funNu = @(nu) 1/(sqrt(2*pi)*sigmaNu).*exp(-(nu-muV).^2/(2*sigmaNu^2));

numin = 0.24;
numax = 0.26;

q2nu = quad(funNu,numin,numax)


%% 15
funE = @(E) 1/(sqrt(2*pi)*sigmaNu)*exp(-(E-muE).^2/(2*sigmaE^2));

Emin = 0;
Emax = 30000;

q2E = quad(funE,Emin,Emax)

funE2 = @(E) exp(-(E-21000).^2/(2*1050^2));
q2E2 = 1/(sqrt(2*pi)*sigmaE).*quad(funE2,Emin,Emax)
%%  16
Emin = 20900 ;
Emax = 21100 ;

numin = 0.245 ;
numax = 0.255 ;

q2cond = quad2d(fun,Emin,Emax,numin,numax)

%%
% pi = 3.14;
sigmaE = 1050 ;	sigmaNu = 0.03 ;
muE = 21000 ;	muV = 0.3 ;
rho = 0.0 ;	nu = 0.30 ;
E1 = 16000 ;	E2 = 26000 ;
nb_E = 50.0 ;

for i = 1:(nb_E+1)
	E = E1 + (i-1)*(E2-E1)/nb_E ;
    y0(i) = 1/(sqrt(2*pi)*sigmaNu)*exp(-(E-muE)^2/(2*sigmaE^2));
    y01(i) = 1/(2*pi*sigmaE*sigmaNu*sqrt(1-rho^2))*exp(-1/(2*(1-rho^2))*((E-muE)^2/sigmaE^2 +(nu-muV)^2/sigmaNu^2 -2*rho*(E-muE)*(nu-muV)/sigmaE/sigmaNu))/(1/(sqrt(2*pi)*sigmaE)*exp(-(nu-muV)^2/(2*sigmaNu^2)));
end

E = (E1:(E2-E1)/nb_E:E2);

figure(1);clf
plot(E,y01,'r');
hold on;
plot(E,y0,'b--')

xlabel('E [MPa]','FontSize',25)
ylabel('f(E)','FontSize',25)

legend('f_{E|\nu}(E)','f_{E}(E)')
legend('boxoff')

set(gca,'FontSize',25,'fontName','Times');
print(gcf,'-depsc2','ConditDensFunctions.eps');



