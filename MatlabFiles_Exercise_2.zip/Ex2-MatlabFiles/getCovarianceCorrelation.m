function [my_covar,my_corre] = getCovarianceCorrelation(A,B)

if size(A) ~= 1
    A = reshape(A',1,size(A,2)*size(A,1));
    B = reshape(B',1,size(B,2)*size(B,1));
end

my_covar(1,1) = mean([A-mean(A)*ones(size(A))].*(A-mean(A)*ones(size(A))));
my_covar(1,2) = mean([A-mean(A)*ones(size(A))].*(B-mean(B)*ones(size(B))));
my_covar(2,1) = mean([B-mean(B)*ones(size(B))].*(A-mean(A)*ones(size(A))));
my_covar(2,2) = mean([B-mean(B)*ones(size(B))].*(B-mean(B)*ones(size(B))));

% my_covar = my_covar*length(Y)/(length(Y)-1);
% my_corre = my_covar./sqrt(var(X,0)*var(Y,0));

my_corre(1,1) = mean([A-mean(A)*ones(size(A))].*(A-mean(A)*ones(size(A))))/sqrt(var(A,1)*var(A,1));
my_corre(1,2) = mean([A-mean(A)*ones(size(A))].*(B-mean(B)*ones(size(B))))/sqrt(var(A,1)*var(B,1));
my_corre(2,1) = mean([B-mean(B)*ones(size(B))].*(A-mean(A)*ones(size(A))))/sqrt(var(B,1)*var(A,1));
my_corre(2,2) = mean([B-mean(B)*ones(size(B))].*(B-mean(B)*ones(size(B))))/sqrt(var(B,1)*var(B,1));

% my_corre = my_covar./sqrt(var(A,1)*var(B,1));

