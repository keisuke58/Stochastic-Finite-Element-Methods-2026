function [r,u,n,w] = getRandom(samp,dim)  


% % %  dim = vector dimension
  
% % %  samp = number of samples
  
    % Discrete RV, integer values between 100 and 150 
    r = randi([100 150],dim,samp);

    % Continuous RV,  
    % uniformly distributed between 20 and 30
    u = 20 + 10*rand(dim,samp);

    % normal distribution
    n = normrnd(25,1,[dim samp]);

    % Weibull distribution
    w = 20 + 10* wblrnd(0.5,0.4,[dim samp]);