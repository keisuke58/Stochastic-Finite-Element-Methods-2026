function [cdf,pdfEmp,cdf2]=getPdfCdf(r)

n = length(r);

r = sort(r);
%% Estimate the cumulative distribution function (CDF)
for i = 1:length(r)
    cdf(i) = numel(r(r<=r(i)))/n; 
end

%% Estimate the probability density function
pdfEmp = zeros(size(r));
% % Central difference
for i= 1:length(r)
    if i==1
        pdfEmp(i) = (cdf(i+1)-cdf(i))/(r(i+1)-r(i));
    elseif i== length(r)
        pdfEmp(i) = (cdf(i)-cdf(i-1))/(r(i)-r(i-1));
    else
        pdfEmp(i) = (cdf(i+1)-cdf(i-1))/(r(i+1)-r(i-1));
    end
end


%% Calculate the CDF from the estimated PDF
cdf2 = zeros(size(r));
cdf2(1) = 0;
cdf2(length(r)) = 1;
for i = 2:length(r)-1
    cdf2(i) = cdf(i-1)+ (r(i)-r(i-1))*(pdfEmp(i-1)+pdfEmp(i+1))/2;
end

