function  [EmpMean,EmpVar,EmpSkew,EmpKurt,EmpMeanIt,EmpVarIt]=get_moments(x)

%% Empirical Mean
EmpMean = sum(x)/numel(x);

%% Empirical Variance
EmpVar = (1/numel(x)*sum(x.^2)-EmpMean.^2);

% EmpVar normalizes Z by N-1 if N>1, where N is the sample size
% %%% Unbiased estimator
N = numel(x);
if N>1
    EmpVar = EmpVar*N/(N-1);
end

EmpKurt=0;
EmpSkew = 0;
EmpVarIt = 0;
EmpMeanIt = 0;

for i = 1:length(x)
    mu0 = EmpMeanIt;
    %% rollling mean    
    EmpMeanIt = EmpMeanIt + (x(i)-EmpMeanIt)/i;
    %% rolling variance
    EmpVarIt =  EmpVarIt*(1-1/ i) + ( x(i) - EmpMeanIt ).^2 / i;
%      EmpVarIt =  EmpVarIt + 1/i*((x(i) - EmpMeanIt)*(x(i)-mu0)-EmpVarIt); % alternative         

    %% Empirical Skewness
    EmpSkew = EmpSkew + power(x(i)-mean(x),3)/(power(EmpVar,1.5)*numel(x));

    %% Empirical Kurtosis
    EmpKurt = EmpKurt + power(x(i)-mean(x),4)/(power(EmpVar,2)*numel(x));
end
% EmpKurt = EmpKurt-3; %excess kurtosis

return


