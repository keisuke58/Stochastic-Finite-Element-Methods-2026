clear all;
clc;

mu = 1;
sigma = 1;
%% Sample space
x = [mu-20*sigma:0.1*sigma:mu+20*sigma];
% x = linspace(mu-20*sigma,mu+20*sigma,400);

%% calculate pdf
pdf_ref = 1/(sqrt(2*pi*sigma^2))*exp(-power(x-mu,2)/(2*sigma^2));
cdf_ref = cdf('Normal',x,mu,sigma);
% define three different values of the means
mu2 = 0.5*mu ;
mu3 = 2*mu ;
mu4 = 10*mu ;
% compute the 3 relative probability density functions
pdf_mu2 = 1/(sqrt(2*pi*sigma^2))*exp(-power(x-mu2,2)/(2*sigma^2));
pdf_mu3 = 1/(sqrt(2*pi*sigma^2))*exp(-power(x-mu3,2)/(2*sigma^2));
pdf_mu4 = 1/(sqrt(2*pi*sigma^2))*exp(-power(x-mu4,2)/(2*sigma^2));

% compute the 3 relative cumulative distribution functions
cdf_mu2 = cdf('Normal',x,mu2,sigma);
cdf_mu3 = cdf('Normal',x,mu3,sigma);
cdf_mu4 = cdf('Normal',x,mu4,sigma);

% plot the different pdfs
h3=figure(3);clf
plot(x,pdf_ref,'k','Linewidth',2)
hold on
plot(x,pdf_mu2,'r','Linewidth',2);
plot(x,pdf_mu3,'b','Linewidth',2);
plot(x,pdf_mu4,'g','Linewidth',2);
set(gca, 'FontSize', 15)
set(gca, 'linewidth', 2)
xlabel( 'Sample space','Interpreter','Latex','Fontsize',20)
xlim ([mu-20*sigma mu+20*sigma])
ylabel('Probability density function','Interpreter','Latex','Fontsize',20)

leg3{1}=strcat('\mu = ',num2str(mu));
leg3{2}=strcat('\mu = ',num2str(0.5*mu));
leg3{3}=strcat('\mu = ',num2str(2*mu));
leg3{4}=strcat('\mu = ',num2str(10*mu));

legend(leg3)
hold off
savefig(h3,'Gaussian_sigmas_pdf.fig');
%close(h3)
%%
h4=figure(4);clf
plot(x,cdf_ref,'k','Linewidth',2);
hold on
plot(x,cdf_mu2,'r','Linewidth',2);
plot(x,cdf_mu3,'b','Linewidth',2);
plot(x,cdf_mu4,'g','Linewidth',2);
leg4{1}=strcat('\mu = ',num2str(mu));
leg4{2}=strcat('\mu = ',num2str(0.5*mu));
leg4{3}=strcat('\mu = ',num2str(2*mu));
leg4{4}=strcat('\mu = ',num2str(10*mu));


legend(leg4)

legend(leg4)
set(gca, 'FontSize', 15)
set(gca, 'linewidth', 2)
xlabel( 'Sample space','Interpreter','Latex','Fontsize',20)
xlim ([mu-20*sigma mu+20*sigma])
% set(gca,'xlim',[0 100])
ylabel('Cumulative distribution function','Interpreter','Latex','Fontsize',20)
hold on
savefig(h4,'Gaussian_sigmas_cdf.fig');

%%
% define three different values of the standard Ex1deviations
sigma2 = 0.5*sigma;
sigma3 = 2*sigma;
sigma4 = 10*sigma;
% compute the 3 relative probability density functions
pdf_sig2 = 1/(sqrt(2*pi*sigma2^2))*exp(-power(x-mu,2)/(2*sigma2^2));
pdf_sig3 = 1/(sqrt(2*pi*sigma3^2))*exp(-power(x-mu,2)/(2*sigma3^2));
pdf_sig4 = 1/(sqrt(2*pi*sigma4^2))*exp(-power(x-mu,2)/(2*sigma4^2));
% compute the 3 relative cumulative distribution functions
cdf_sig2 = cdf('Normal',x,mu,sigma2);
cdf_sig3 = cdf('Normal',x,mu,sigma3);
cdf_sig4 = cdf('Normal',x,mu,sigma4);
% plot the diffents pdfs
h1=figure(1);clf
plot(x,pdf_ref,'k','Linewidth',2)
hold on
% yy = pdf('Normal',x,mu,sigma);
% plot(x,yy,'r','Linewidth',2);
hold on
plot(x,pdf_sig2,'r','Linewidth',2);
plot(x,pdf_sig3,'b','Linewidth',2);
plot(x,pdf_sig4,'g','Linewidth',2);
set(gca, 'FontSize', 15)
set(gca, 'linewidth', 2)
xlabel( 'Sample space','Interpreter','Latex','Fontsize',20)
xlim ([mu-20*sigma mu+20*sigma])
ylabel('Probability density function','Interpreter','Latex','Fontsize',20)
leg1{1}=strcat('\sigma = ',num2str(sigma));
leg1{2}=strcat('\sigma = ',num2str(0.5*sigma));
leg1{3}=strcat('\sigma = ',num2str(2*sigma));
leg1{4}=strcat('\sigma = ',num2str(10*sigma));
legend(leg1)
hold off
savefig(h1,'Gaussian_sigmas_pdf.fig');
%close(h1)

% plot the different cdfs
h2=figure(2);clf
plot(x,cdf_ref,'k','Linewidth',2);
hold on
plot(x,cdf_sig2,'r','Linewidth',2);
plot(x,cdf_sig3,'b','Linewidth',2);
plot(x,cdf_sig4,'g','Linewidth',2);
leg2{1}=strcat('\sigma = ',num2str(sigma));
leg2{2}=strcat('\sigma = ',num2str(0.5*sigma));
leg2{3}=strcat('\sigma = ',num2str(2*sigma));
leg2{4}=strcat('\sigma = ',num2str(10*sigma));
legend(leg2)
set(gca, 'FontSize', 15)
set(gca, 'linewidth', 2)
xlabel( 'Sample space','Interpreter','Latex','Fontsize',20)
xlim ([mu-20*sigma mu+20*sigma])
ylabel('Cumulative distribution function','Interpreter','Latex','Fontsize',20)



















