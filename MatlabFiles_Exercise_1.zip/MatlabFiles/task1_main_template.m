%%%%%%%%%%%%%%%%%%%%%%% Task1_main.m %%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;

%% paramters
% disttype = 'normal';   % uniform, normal or weibul
% n = 10;
% mu = 
% sigma =  

%%
% getRandom(disttype,n,mu,sigma,a,b) 
%           - disttype = distribution type (e.g. 'uniform','normal','weibull') 
%           - n = number of samples
%           - mu and sigma are mean and variance (sigma is the amplitude (range/2) in the case of uniform distribution)
%           - a and b are the weibull scale and shape parameters
r = getRandom(disttype,n,mu,sigma,a,b);
% r = getRandomDiscrete(disttype,n,mu,sigma,a,b);

%% plot distribution
figure(10);clf
plot(r,'o')
xlabel('Sample number')
ylabel('r')
% set(gca,'ylim',[0 50])

%% Moments
[EmpMean,EmpVar,EmpSkew,EmpKurt,EmpMeanIt,EmpVarIt]=get_moments(r);



%% linear/non-linear moments
% X1 = [-3,1,2,3,4,5];
% X2 = [0,1,2,2,5,10];
