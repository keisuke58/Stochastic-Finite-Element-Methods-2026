clear all;
clc;

n = 100;
r=randi([100 150],1,n);
% r = sort(r); % sort vector elements 

%% Gaussian distribution
% r = round(normrnd(125,5,[1 n]));
% r = sort(r); % sort vector elements 

%% Weibuul distribution
% r=round(100+50*wblrnd(1,0.5,[1,n]));
% r = sort(r); % sort vector elements 
%%
plot(r,'o')
%%
r = sort(r);
for i = 1:length(r)
    pmf(i) = sum(r==r(i));
end
pmf = pmf/n;

plot(pmf,'o')


%% Calculating the cmf (Option 1)
space = 100:150;
%%
cmft = 0;
count=0;
for i=1:length(space)
    for j = 1:length(r)
        if space(i)== r(j)
            count=count+1;
            rc(count)= r(j);
            cmft = cmft+pmf(j); 
            break;
        end        
    end
    cmf(i) = cmft;
end
% cmf = cmf/n;
%% Calculating the cmf (Option 2)
for i = 1:length(r)
    cmf2(i) = sum(r<=r(i));
end
cmf2 = cmf2/n;



%% Plot
figure(1);clf
plot(r,pmf,'o')
set(gca,'ylim',[0 1],'xlim',[100 150])
xlabel('Number of Suitcases')
ylabel('Probability Mass Function')

figure(2);clf
plot(space,cmf,'-')
plot(space,cmf,'-',r,cmf2,'o')
grid on
xlabel('Number of Suitcases')
ylabel('Cumulative Mass Function')
