clear all;
clc;

format short

n = 1000;

%% Uniform distpchipribution
% r=20+10*rand(1,n);
% % % r = unifrnd(20,30,1,n);
% r = sort(r); % sort vector elements 
% 
% Er = 25;
% PEr = 1/(30-20);france presidential polls

%% Gaussian distribution
sigma=1;
mu = 25;

r = normrnd(mu,sigma,[1 n]);
r = sort(r); % sort vector elements 

Er = 25
PEr= 1/(sqrt(2*pi*sigma^2))*exp(-(Er-mu)^2/(2*sigma^2))

%% Weibuul distribution
% r=10*wblrnd(0.2,1,[1,n]);
% r = sort(r); % sort vector elements 


%%
space = linspace(20,30,n);
cdf1(1)=0;
for i = 1:length(r)
    cdf1(i) = numel(r(r<=r(i)))/n; 
end

% % Matlab built-in functions
% cdff=cdf('Uniform',r,20,30);
cdff=cdf('Normal',r,mu,sigma);

cdfn = cdf1;
cdfi = interp1(r,cdfn,space,'linear');
cdfi(isnan(cdfi)&space<25) = 0 ;
cdfi(isnan(cdfi)&space>25) = 1 ;
cdfi = cdfi/sum(r);

figure(2);clf
% cdfplot(r)
% hold on
plot(r,cdf1,'o',r,cdff)
% plot(r,cdfn,'o',space,cdfi,r,cdff)
set(gca,'xlim',[20 30])
set(gca,'ylim',[0 1])
grid on
axis square
xlabel('Number of Suitcases')
ylabel('CDF')

%% pdf
% dx = diff(r);
% pdf= diff(cdfnorm);
% pdf2 = gradient(cdf);
% pdf2 = pdf./dx;
% rnorm = (r-20)/10;
for i= 1:length(space)-1
%     pdf(i) = (cdfn(i+1)-cdfn(i))/(space(i+1)-space(i));
    pdf(i) = (cdfn(i+1)-cdfn(i))/(r(i+1)-r(i));
end

% int_pdf=trapz(space(1:end-1),pdf)
int_pdf=trapz(r(1:end-1),pdf)
mean_pdf = mean(pdf)
%% Plot
figure(1);clf
plot(space(1:end-1),pdf,'-')
% plot(r(1:end-1),pdf,'-')
set(gca,'xlim',[20 30])
set(gca,'ylim',[0 1])
grid on
xlabel('Number of Suitcases')
ylabel('PDF')




%% Moments of probability
[EmpMean,EmpVar,EmpSkew,EmpKurt] = get_moments(r);
% get_moments(r)
% compare_moments(r)







