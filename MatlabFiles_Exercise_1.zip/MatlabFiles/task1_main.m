%%%%%%%%%%%%%%%%%%%%%%% Task1_main.m %%%%%%%%%%%%%%%%%%%%%%%

clear all;
clc;

restoredefaultpath
%% paramters
disttype = 'normal';   % uniform, normal or weibul
n = 100; % number of samples

mu = 10;
sigma =  1;
a = 0.2;
b = 1;
%%
% getRandom(disttype,n,mu,sigma,a,b) 
%           - disttype = distribution type (e.g. 'uniform','normal','weibull') 
%           - n = number of samples
%           - mu and sigma are mean and variance (sigma is the amplitude (range/2) in the case of uniform distribution)
%           - a and b are the weibull scale and shape parameters
r = getRandom(disttype,n,mu,sigma,a,b);
% r = getRandomDiscrete(disttype,n,mu,sigma,a,b);

%% plot distribution
figure(10);clf
plot(r,'o')
xlabel('Sample number')
ylabel('r')
% set(gca,'ylim',[0 50])

%% get pdf and cdf
[cdf,pdfEmp,cdf2] = getPdfCdf(r);

r = sort(r);

% matlab built-in function for cdf
[Fx,x1] = ecdf(r);

% % plots
figure(21);clf;
plot(x1,Fx,'.',r,cdf,'--','LineWidth',2)
% plot(x1,Fx,'.',r,cdf,'--',r,cdf2,'.','LineWidth',2)
set(gca,'ylim',[0 1])
ylabel('Cumulative Distribution Function')

%%
figure(22);clf
histogram(r,10,'Normalization','pdf')  % histogram in the form of pdf
hold on

range = linspace(mu-5*sigma,mu+5*sigma,100); % assign range to plot the pdf

% % alternative 1 (fitdist function)
pd = fitdist(r','Normal');
y = pdf(pd,range); % pdf function plot pdf from pd structure in the range given
plot(range,y,'b-')
% % alternative 2: for normal distribution one may also fit a pdf curve
[muN,sigmaN,muCI,sigmaCI] = normfit(r);
pd = makedist('Normal','mu',muN,'sigma',sigmaN);
y = pdf(pd,range);
figure(22)
plot(range,y,'r--')
ylabel('Probability Density Function')



%% pdf comparison - fitted curve with numerical derivation of CDF
figure(23);clf;
plot(r,pdfEmp,'-.')
hold on
plot(range,y,'r-','LineWidth',2.0)
set(gca,'ylim',[0 1])
ylabel('Probability Density Function')
grid on

%% Moments
[EmpMean,EmpVar,EmpSkew,EmpKurt,EmpMeanIt,EmpVarIt]=get_moments(r);
EmpStd = sqrt(EmpVar);  % empirical standard deviation
mat_mean = mean(r);
mat_var = var(r);
mat_std = sqrt(var(r));
mat_skew = skewness(r);
mat_kurt = kurtosis(r);

fprintf('\nNumber of samples = %d\n',n);
fprintf('Mean: Matlab function = %3.4f, Empiracal = %3.4f\n',mat_mean,EmpMean)
fprintf('Standard: Matlab function = %3.4f, Empiracal = %3.4f\n',mat_std,EmpStd)
fprintf('Variance: Matlab function = %3.4f, Empiracal = %3.4f\n',mat_var,EmpVar)
fprintf('\nVariance: Matlab function = %3.4f, EmpVarIt = %3.4f\n',mat_var,EmpVarIt)

%% linear/non-linear moments  
X1 = [-3,1,2,3,4,5];
X2 = [0,1,2,2,5,10];
[EmpMean,EmpVar,EmpSkew,EmpKurt] =get_moments(X2);

% % check if moments are linear operators
moment1 = mean(2*X1+3*X2)
moment2 = 2*mean(X1)+3*mean(X2)

moment1 = var(2*X1+3*X2)
moment2 = 2*var(X1)+3*var(X2)


