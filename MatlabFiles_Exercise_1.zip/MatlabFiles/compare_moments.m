function [MatMean,MatVar,MatSkew,MatKurt]=compare_moments(x)
%% Matlab built-in functions
MatMean = mean(x)
MatVar = var(x)
MatSkew = skewness(x)
MatKurt = kurtosis(x)
