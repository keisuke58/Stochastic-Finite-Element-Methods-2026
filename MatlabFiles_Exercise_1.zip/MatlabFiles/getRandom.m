%%%%% function getRandom()

function [r] = getRandom(type,n,mu,sigma,a,b)

if strcmp(type,'uniform')
    r = mu + 10*rand(1,n);
    
elseif strcmp(type,'normal')
    r = normrnd(mu,sigma,[1 n]);
    
elseif strcmp(type,'weibull')
    r = mu+sigma*wblrnd(a,b,[1,n]);  % a and b are scale and shape parameters
else
    disp('Error, distribution not available')
end

end